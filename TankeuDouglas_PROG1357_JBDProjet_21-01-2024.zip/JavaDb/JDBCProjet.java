package JavaDb;

import java.util.Scanner;

import JavaDb.*;


public class JDBCProjet {

    private static void afficherMenu() {

        System.out.println("Menu :");
        System.out.println("1. Lister les éléments");
        System.out.println("2. Ajouter un élément");
        System.out.println("3. Supprimer un élément");
        System.out.println("4. Update");
        System.out.println("5. exit");
        System.out.print("Choisissez une option : ");
    }
    public static void main(String[] args) {
       
        Connectdb Connectdb = new Connectdb();
        Connectdb.connect();
        
        Scanner scanner = new Scanner(System.in);


        while (true) {

            afficherMenu();

            int choix = scanner.nextInt();

            scanner.nextLine(); // Pour consommer le saut de ligne

            switch (choix) {
                case 1:
                    Listings listings = new Listings(); 
                    break;
                case 2:
                    AddDb addDb = new AddDb();
                    break;
                case 3:
                    DeleteDb deleteDb = new DeleteDb();
                    break;
                case 4:
                    UpdateDb updateDb = new UpdateDb();
                    break;
                case 5:
                    System.out.println("Programme terminé.");
                    System.exit(0);
                default:
                    System.out.println("Choix invalide. Veuillez choisir à nouveau.");
            }
        }
    }  
}

