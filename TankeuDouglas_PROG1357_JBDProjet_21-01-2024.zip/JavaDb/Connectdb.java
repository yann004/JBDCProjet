package JavaDb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Statement;


/**
 *
 * @author postgresqltutorial.com
 */

public class Connectdb {
     
    private final String user = "postgres";
    private final String password = "admin";
    
    
    /**
     * Connect to the PostgreSQL database
     *
     * @return a Connection object
     */

public Connection connect() {

    Scanner scanner = new Scanner(System.in);

    // Demander à l'utilisateur le nom de la base de données

    System.out.print("Veuillez entrer le nom de la base de données PostgreSQL : ");
    String nomBaseDeDonnees = scanner.nextLine();

    // Vérifier que le nom de la base de données n'est pas null ou vide

    if (nomBaseDeDonnees == null || nomBaseDeDonnees.trim().isEmpty()) {

        System.out.println("Nom de la base de données invalide.");

        return null; 
    }

    // Construire l'URL de connexion

    String url = "jdbc:postgresql://localhost:5432/" + nomBaseDeDonnees;

    Connection plug = null;

    try {
        // Connexion à la base de données

        plug = DriverManager.getConnection(url, user, password);
        System.out.println("Connected to the PostgreSQL server successfully.");
        System.out.println(plug);

   

        // Vérifier si la base de données existe, et la créer si elle n'existe pas

        url = "jdbc:postgresql://localhost:5432/";
        plug = DriverManager.getConnection(url, user, password);
        Statement statement = plug.createStatement();
        String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " + nomBaseDeDonnees;
        statement.executeUpdate(createDatabaseQuery);
        statement.close();
        
        System.out.println("Base de données vérifiée/créée avec succès.");
   

    } catch (SQLException e) {
        System.out.println("Erreur lors de la connexion à la base de données : " + e.getMessage());
        
    } finally {
        // Fermer le scanner
        if (scanner != null) {
            scanner.close();
        }
    }

    return plug;
}

}