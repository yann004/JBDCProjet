package JavaDb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteDb {

    

    private static void supprimerElementTable(Connection connexion, String nomTable) throws SQLException {

        Scanner scanner = new Scanner(System.in);

        System.out.print("\nEntrez l'ID de l'élément à supprimer de la table " + nomTable + " : ");

        // Validation de l'ID (être un entier)

        if (!scanner.hasNextInt()) {
            System.out.println("L'ID doit être un entier. Suppression annulée.");
            scanner.nextLine(); 
            return;
        }
        int idElement = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "DELETE FROM " + nomTable + " WHERE id_" + nomTable.toLowerCase() + " = ?";
        
        try (PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, idElement);
            int lignesSupprimees = preparedStatement.executeUpdate();

            if (lignesSupprimees > 0) {
                System.out.println("Élément supprimé avec succès.");
            } else {
                System.out.println("Aucun élément correspondant à l'ID spécifié n'a été trouvé.");
            }
        }
    }

    public static void main(String[] args) {

        // Informations de connexion à la base de données

        String url = "jdbc:postgresql://localhost:5432/ma_base_de_donnees";
        String utilisateur = "mon_utilisateur";
        String motDePasse = "mon_mot_de_passe";
        
        try (Connection connexion = DriverManager.getConnection(url, utilisateur, motDePasse)) {
            
            System.out.println("Connexion à la base de données établie avec succès.");

            Listings.listerElementsTable(connexion, "Utilisations");
            Listings.listerElementsTable(connexion, "Capteurs");
            Listings.listerElementsTable(connexion, "Mesures");

            // suppression d'éléments

            supprimerElementTable(connexion, "Utilisations");

            // Liste à nouveau après la suppression

            Listings.listerElementsTable(connexion, "Utilisations");

        } catch (SQLException e) {
            System.err.println("Erreur de connexion à la base de données : " + e.getMessage());
        }
    }
   
}


