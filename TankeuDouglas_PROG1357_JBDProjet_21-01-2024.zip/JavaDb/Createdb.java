package JavaDb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Createdb {
    


    public static void main(String[] args) {

        Connectdb Connectdb = new Connectdb();
        Connectdb.connect();

        // Informations de connexion à la base de données

        String url = "jdbc:postgresql://localhost:5432/";
        String utilisateur = "mon_utilisateur";
        String motDePasse = "mon_mot_de_passe";
        String nomBaseDeDonnees = "ma_base_de_donnees";

        // Établir la connexion
        try (Connection connexion = DriverManager.getConnection(url, utilisateur, motDePasse)) {

            // Création de la base de données s'il n'existe pas

            String sqlCreationBaseDeDonnees = "CREATE DATABASE IF NOT EXISTS " + nomBaseDeDonnees;

            try (Statement statement = connexion.createStatement()) {
                statement.executeUpdate(sqlCreationBaseDeDonnees);
                System.out.println("Base de données créée ou existante.");
            }

            // Utilisation de la base de données

            String urlAvecNomBase = url + nomBaseDeDonnees;
            try (Connection nouvelleConnexion = DriverManager.getConnection(urlAvecNomBase, utilisateur, motDePasse);
                 Statement statement = nouvelleConnexion.createStatement()) {

                // Création de la table Utilisations
                String sqlCreationTableUtilisations = "CREATE TABLE IF NOT EXISTS Utilisations (" +
                        "id_utilisation INT PRIMARY KEY," +
                        "nom_utilisation VARCHAR(255) NOT NULL)";
                statement.executeUpdate(sqlCreationTableUtilisations);
                System.out.println("Table Utilisations créée ou existante.");

                // Création de la table Capteurs
                String sqlCreationTableCapteurs = "CREATE TABLE IF NOT EXISTS Capteurs (" +
                        "id_capteur INT PRIMARY KEY," +
                        "nom_capteur VARCHAR(255) NOT NULL," +
                        "type_capteur VARCHAR(100) NOT NULL," +
                        "id_utilisation INT," +
                        "FOREIGN KEY (id_utilisation) REFERENCES Utilisations(id_utilisation))";
                statement.executeUpdate(sqlCreationTableCapteurs);
                System.out.println("Table Capteurs créée ou existante.");

                // Création de la table Mesures
                String sqlCreationTableMesures = "CREATE TABLE IF NOT EXISTS Mesures (" +
                        "id_mesure INT PRIMARY KEY," +
                        "id_capteur INT," +
                        "valeur_mesure FLOAT NOT NULL," +
                        "timestamp_mesure TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                        "FOREIGN KEY (id_capteur) REFERENCES Capteurs(id_capteur))";
                statement.executeUpdate(sqlCreationTableMesures);
                System.out.println("Table Mesures créée ou existante.");

            }

        } catch (SQLException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
    }
}
