package JavaDb;
import java.util.Scanner;

public class JDBCProjet {

    private static void afficherMenu() {
        System.out.println("Menu :");
        System.out.println("1. Lister les éléments");
        System.out.println("2. Ajouter un élément");
        System.out.println("3. Supprimer un élément");
        System.out.println("4. Update");
        System.out.println("5. exit");
        System.out.print("Choisissez une option : ");
    }

    private static void autocloable(Scanner scanner) {
        try (scanner) {
            //while (true) {
                afficherMenu();
                int choix = scanner.nextInt();
                scanner.nextLine(); // Pour consommer le saut de ligne
              
                switch (choix) {
                    case 1:
                        Listings listings = new Listings();
                        listings.main(new String[]{});
                        break;
                    case 2:
                        AddDb addDb = new AddDb();
                        addDb.main(new String[]{});
                        break;
                    case 3:
                        DeleteDb deleteDb = new DeleteDb();
                        deleteDb.main(new String[]{});
                        break;
                    case 4:
                        UpdateDb updateDb = new UpdateDb();
                        updateDb.main(new String[]{});
                        break;
                    case 5:
                        System.out.println("Programme terminé.");
                        return; // sortir de la méthode autocloable() et donc fermer le scanner
                    default:
                        System.out.println("Choix invalide. Veuillez choisir à nouveau.");
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Connectdb databaseUtil = new Connectdb();
        String dbNameToCreate = "Objet";

        databaseUtil.createDatabaseIfNotExists(dbNameToCreate);
        databaseUtil.CreateTable(dbNameToCreate);

        try (Scanner scanner = new Scanner(System.in)) {
            autocloable(scanner);
        }
    }
}
