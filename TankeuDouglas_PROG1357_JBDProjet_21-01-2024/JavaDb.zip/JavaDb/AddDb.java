package JavaDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddDb {
   
    
    
        // Méthode pour valider le nom avec l'expression régulière

        private static boolean validerNom(String nom) {
            Pattern pattern = Pattern.compile("^[a-zA-Z0-9\\-_]*$");
            Matcher matcher = pattern.matcher(nom);
            return matcher.matches();
        }

        private static void afficherMenu() {
            try {
                System.out.println("Menu insertion :");
                System.out.println("1. Ajouter une Utilisation");
                System.out.println("2. Ajouter un Capteur");
                System.out.println("3. Ajouter une Mesure");
                System.out.println("4. exit");
               
            } catch (Exception e) {
                System.err.println("Erreur lors de l'affichage du menu : " + e.getMessage());
            }
        }

        private static void ajouterUtilisation(Connection connexion, Scanner scanner) throws SQLException {
                
            System.out.print("Entrez le nom de l'utilisation : ");
            String nomUtilisation = scanner.nextLine();
    
            // Validation du nom d'utilisation != vide
    
            if (nomUtilisation.trim().isEmpty()) {
                System.out.println("Le nom de l'utilisation ne peut pas être vide. Veuillez réessayer.");
                return;
            }
    
            // Validation du nom d'utilisation avec l'expression régulière
    
           /*  if (!validerNom(nomUtilisation)) {
                System.out.println("Le nom de l'utilisation ne correspond pas au motif spécifié. Veuillez réessayer.");
                return;
            }*/
    
            String sql = "INSERT INTO Utilisations (id_utilisation, nom_utilisation) VALUES (DEFAULT, ?)";

            try (PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {
                preparedStatement.setString(1, nomUtilisation);
                preparedStatement.executeUpdate();
                System.out.println("Utilisation ajoutée avec succès.");
            }
        }

        private static void ajouterCapteur(Connection connexion, Scanner scanner) throws SQLException {

            System.out.print("Entrez le nom du capteur : ");
            String nomCapteur = scanner.nextLine();
            System.out.print("Entrez le type du capteur : ");
            String typeCapteur = scanner.nextLine();
            System.out.print("Entrez l'ID de l'utilisation associée : ");
            
            // Validation de l'ID de l'utilisation (être un entier)
            if (!scanner.hasNextInt()) {
                System.out.println("L'ID de l'utilisation doit être un entier. Veuillez réessayer.");
                scanner.nextLine();
                return;
            }
            int idUtilisation = scanner.nextInt();
            scanner.nextLine(); 
    
            // Validation du nom du capteur avec l'expression régulière
            
            if (!validerNom(nomCapteur)) {
                System.out.println("Le nom du capteur ne correspond pas au motif spécifié. Veuillez réessayer.");
                return;
            }
        
            // Validation du nom du capteur (non vide)
    
            if (nomCapteur.trim().isEmpty()) {
                System.out.println("Le nom du capteur ne peut pas être vide. Veuillez réessayer.");
                return;
            }
        
            // Validation du type du capteur non vide)
            if (typeCapteur.trim().isEmpty()) {
                System.out.println("Le type du capteur ne peut pas être vide. Veuillez réessayer.");
                return;
            }
        
            String sql = "INSERT INTO Capteurs (id_capteur, nom_capteur, type_capteur, id_utilisation) " +
                    "VALUES (DEFAULT, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {
                preparedStatement.setString(1, nomCapteur);
                preparedStatement.setString(2, typeCapteur);
                preparedStatement.setInt(3, idUtilisation);
                preparedStatement.executeUpdate();
                System.out.println("Capteur ajouté avec succès.");
            }
        }

        private static void ajouterMesure(Connection connexion, Scanner scanner) throws SQLException {

            System.out.print("Entrez l'ID du capteur associé : ");
            
            // Validation de l'ID du capteur ( être un entier)
    
            if (!scanner.hasNextInt()) {
                System.out.println("L'ID du capteur doit être un entier. Veuillez réessayer.");
                scanner.nextLine(); 
                return;
            }
            int idCapteur = scanner.nextInt();
            scanner.nextLine(); 
            
            System.out.print("Entrez la valeur de la mesure : ");
            
            // Validation de la valeur de la mesure (être un nombre à virgule flottante)
    
            if (!scanner.hasNextFloat()) {
                System.out.println("La valeur de la mesure doit être un nombre. Veuillez réessayer.");
                scanner.nextLine(); 
                return;
            }
            float valeurMesure = scanner.nextFloat();
            scanner.nextLine(); 
        
            String sql = "INSERT INTO Mesures (id_mesure, id_capteur, valeur_mesure) VALUES (DEFAULT, ?, ?)";
            try (PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {
                preparedStatement.setInt(1, idCapteur);
                preparedStatement.setFloat(2, valeurMesure);
                preparedStatement.executeUpdate();
                System.out.println("Mesure ajoutée avec succès.");
            }
        }
    
        public static void main(String[] args) {

            Connection connection = Connectdb.getConnection();
    
            try (connection) {

                System.out.println("Connexion à la base de données établie avec succès.");
    
                Scanner scanner = new Scanner(System.in);
    
                while (true) {

                    afficherMenu();
    
                    int choix = scanner.nextInt();

                    scanner.nextLine(); 
    
                    switch (choix) {
                        
                        case 1:
                            ajouterUtilisation(connection, scanner);
                            break;
                        case 2:
                            ajouterCapteur(connection, scanner);
                            break;
                        case 3:
                            ajouterMesure(connection, scanner);
                            break;
                        case 4:
                            System.out.println("End");
                            return;
                        default:
                            System.out.println("Choix non valide. Veuillez réessayer.");
                    }
                }
    
            } catch (SQLException e) {
                System.err.println("Erreur de connexion à la base de données : " + e.getMessage());
            }
        }   
    }


    


