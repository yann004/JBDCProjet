package JavaDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Listings {
   
    public static void afficherUtilisation(ResultSet resultSet) throws SQLException {
        int idUtilisation = resultSet.getInt("id_utilisation");
        String nomUtilisation = resultSet.getString("nom_utilisation");
        System.out.println("ID : " + idUtilisation + ", Nom : " + nomUtilisation);
    }

    public static void afficherCapteur(ResultSet resultSet) throws SQLException {
        int idCapteur = resultSet.getInt("id_capteur");
        String nomCapteur = resultSet.getString("nom_capteur");
        String typeCapteur = resultSet.getString("type_capteur");
        int idUtilisation = resultSet.getInt("id_utilisation");
        System.out.println("ID : " + idCapteur + ", Nom : " + nomCapteur + ", Type : " + typeCapteur + ", ID Utilisation : " + idUtilisation);
    }

    public static void afficherMesure(ResultSet resultSet) throws SQLException {
        int idMesure = resultSet.getInt("id_mesure");
        int idCapteur = resultSet.getInt("id_capteur");
        float valeurMesure = resultSet.getFloat("valeur_mesure");
        String timestampMesure = resultSet.getString("timestamp_mesure");
        System.out.println("ID : " + idMesure + ", ID Capteur : " + idCapteur + ", Valeur : " + valeurMesure + ", Timestamp : " + timestampMesure);
    }

    public static void listerElementsTable(Connection connexion, String nomTable) throws SQLException {
        System.out.println("\nListe des éléments de la table " + nomTable + " :");

        String sql = "SELECT * FROM " + nomTable;
        try (PreparedStatement preparedStatement = connexion.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                switch (nomTable) {
                    case "Utilisations":
                        afficherUtilisation(resultSet);
                        break;
                    case "Capteurs":
                        afficherCapteur(resultSet);
                        break;
                    case "Mesures":
                        afficherMesure(resultSet);
                        break;
                    default:
                        System.out.println("Table non reconnue : " + nomTable);
                }
            }

        }
    }
    
    public static void main(String[] args) {
        
        Connection connection = Connectdb.getConnection();

        try (connection) {
            System.out.println("Connexion à la base de données établie avec succès.");

            listerElementsTable(connection, "Utilisations");
            listerElementsTable(connection, "Capteurs");
            listerElementsTable(connection, "Mesures");

        } catch (SQLException e) {

            System.err.println("Erreur de connexion à la base de données : " + e.getMessage());
        }
    }
 
}
