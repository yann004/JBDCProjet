package JavaDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteDb {

    

    private static void supprimerElementTable(Connection connexion, String nomTable) throws SQLException {

        Scanner scanner = new Scanner(System.in);

        System.out.print("\nEntrez l'ID de l'élément à supprimer de la table " + nomTable + " : ");

        // Validation de l'ID (être un entier)

        if (!scanner.hasNextInt()) {
            System.out.println("L'ID doit être un entier. Suppression annulée.");
            scanner.nextLine(); 
            return;
        }
        int idElement = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "DELETE FROM " + nomTable + " WHERE id_utilisation = ?";
        
        try (PreparedStatement preparedStatement = connexion.prepareStatement(sql)) {
            preparedStatement.setInt(1, idElement);
            int lignesSupprimees = preparedStatement.executeUpdate();

            if (lignesSupprimees > 0) {
                System.out.println("Élément supprimé avec succès.");
            } else {
                System.out.println("Aucun élément correspondant à l'ID spécifié n'a été trouvé.");
            }
        }
        scanner.close();
    }

    public static void main(String[] args) {

        Connection connection = Connectdb.getConnection();

        try (connection) {
            
            System.out.println("Connexion à la base de données établie avec succès.");

            Listings.listerElementsTable(connection, "Utilisations");
            Listings.listerElementsTable(connection, "Capteurs");
            Listings.listerElementsTable(connection, "Mesures");

            // suppression d'éléments

            supprimerElementTable(connection, "Utilisations");

            // Liste à nouveau après la suppression

            Listings.listerElementsTable(connection, "Utilisations");

        } catch (SQLException e) {
            System.err.println("Erreur de connexion à la base de données : " + e.getMessage());
        }
    }
   
}


