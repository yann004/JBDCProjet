package JavaDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDb {
    

     private static void updateUtilisations(Connection connection) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Utilisations SET nom_utilisation = ? WHERE id_utilisation = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Nouveau nom pour Utilisation (id_utilisation = ?) : ");
            String nouveauNomUtilisation = scanner.nextLine();

            System.out.print("Entrez l'id_utilisation pour la mise à jour : ");
            int idUtilisationAUpdate = scanner.nextInt();

            preparedStatement.setString(1, nouveauNomUtilisation);
            preparedStatement.setInt(2, idUtilisationAUpdate);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Nombre de lignes affectées dans Utilisations : " + rowsAffected);
        }
    }

    private static void updateCapteurs(Connection connection) throws SQLException {

        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Capteurs SET nom_capteur = ? WHERE id_capteur = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Nouveau nom pour Capteur (id_capteur = ?) : ");
            String nouveauNomCapteur = scanner.nextLine();

            System.out.print("Entrez l'id_capteur pour la mise à jour : ");
            int idCapteurAUpdate = scanner.nextInt();

            preparedStatement.setString(1, nouveauNomCapteur);
            preparedStatement.setInt(2, idCapteurAUpdate);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Nombre de lignes affectées dans Capteurs : " + rowsAffected);
        }
    }

    private static void updateMesures(Connection connection) throws SQLException {

        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Mesures SET valeur_mesure = ? WHERE id_mesure = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Nouvelle valeur pour Mesure (id_mesure = ?) : ");
            float nouvelleValeurMesure = scanner.nextFloat();

            System.out.print("Entrez l'id_mesure pour la mise à jour : ");
            int idMesureAUpdate = scanner.nextInt();

            preparedStatement.setFloat(1, nouvelleValeurMesure);
            preparedStatement.setInt(2, idMesureAUpdate);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Nombre de lignes affectées dans Mesures : " + rowsAffected);
        }
    }


    public static void main(String[] args) {

        Connection connection = Connectdb.getConnection();
    
            try ( connection ) {
                while (true) {
                    System.out.println("Menu de mise à jour :");
                    System.out.println("1. Mise à jour de la table Utilisations");
                    System.out.println("2. Mise à jour de la table Capteurs");
                    System.out.println("3. Mise à jour de la table Mesures");
                    System.out.println("4. Quitter");
                    System.out.print("Veuillez choisir une option : ");
    
                    Scanner scanner = new Scanner(System.in);
                    int choice = scanner.nextInt();
    
                    switch (choice) {
                        case 1:
                            updateUtilisations(connection);
                            break;
                        case 2:
                            updateCapteurs(connection);
                            break;
                        case 3:
                            updateMesures(connection);
                            break;
                        case 4:
                            System.out.println("Programme terminé.");
                            return;
                        default:
                            System.out.println("Option non valide. Veuillez réessayer.");
                    }
                }
            } catch (SQLException e) {
                System.out.println("Erreur lors de la connexion à la base de données : " + e.getMessage());
            }
        }
        
}
